package Tema1.Boletin2XML.ejercicio1.repositorio;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import Tema1.Boletin2XML.ejercicio1.modelo.Empleado;
import Tema1.Boletin2XML.ejercicio1.modelo.Puesto;
import Tema1.ejemplosFicheros.EjemploFichero;

import java.io.File;
import java.util.List;

public class UtilesXMLDom {

	private static final String RUTA_RESOURCES = "src/main/resources/";
	private static final Logger logger = LogManager.getLogger(UtilesXMLDom.class);

	private void escribeDocumentoEnFichero(Document documento, String nombreFichero) throws TransformerException {
		// clases necesarias finalizar la creación del archivo XML
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer;
		transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(documento);
		StreamResult resultado = new StreamResult(new File(this.RUTA_RESOURCES + nombreFichero));
		transformer.transform(source, resultado);
	}

	private Element creaElemento(String nombreElemento, String valorElemento, Element padre, Document documento) {
		Element elemento = documento.createElement(nombreElemento);
		if (valorElemento != null) {
			Text texto = documento.createTextNode(valorElemento);
			elemento.appendChild(texto);// Cargo el elemento con el valor
		}
		padre.appendChild(elemento);// Se lo asigno a su padre como Hijo
		return elemento;
	}

	private void agregaEmpleadoADocumento(Document documento, Element padre, Empleado e) {
		// Para cada una de los atributos de persona, creo un elemento hijo
		Element nombre = this.creaElemento("nombreApellido", e.getNombreApellidos(), padre, documento);
		Element empresa = this.creaElemento("empresa", e.getEmpresa(), padre, documento);
		if (Integer.toString(e.getEdad()) != null) {/* Aqui crea edad si no es nula */
			Element edad = this.creaElemento("edad", Integer.toString(e.getEdad()), padre, documento);
		}
		// El identificador lo vamos a crear como un atributo de la etiqueta empleado
		if (e.getId() != null) {
			padre.setAttribute("identificador", e.getId());
		}
		Puesto p = e.getPuesto();
		Element puesto = this.creaElemento("puesto", null, padre, documento);
		Element nombrePuesto = this.creaElemento("nombrePuesto", p.getNombrePuesto(), puesto, documento);
		Element salario = this.creaElemento("salario", Integer.toString(p.getSalario()), puesto, documento);

		if (p.getDepartamento() != null) {
			Element departamento = this.creaElemento("Departamento", p.getDepartamento(), puesto, documento);
		}
		if (p.getId() != null) {
			Element id = this.creaElemento("Identificador", p.getId(), puesto, documento);
		}
	}

	private Document construyoObjetoDocumento(String nombreRaiz) throws ParserConfigurationException {
		Document documento = null;
		DocumentBuilderFactory factoria = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factoria.newDocumentBuilder();
		DOMImplementation implementacion = builder.getDOMImplementation();
		documento = implementacion.createDocument(null, nombreRaiz, null);
		// Primer parámetro uri: si null no está validado por ninguna ruta
		// segundo parámetro: nombre fichero
		// tercer parámetro: document type Por defecto null Permite asociar DTD
		return documento;
	}

	public void escribeEmpleadoEnXML(String nombreFichero, List<Empleado> empleados) {
		try {
			Document documento = this.construyoObjetoDocumento("empleado");
			// Recupero la raíz del documento
			Element raiz = documento.getDocumentElement();
			for (Empleado e : empleados) {
				agregaEmpleadoADocumento(documento, raiz, e );
			}
			escribeDocumentoEnFichero(documento, nombreFichero);
		} catch (ParserConfigurationException e1) {
			logger.error(e1.getMessage());
		} catch (TransformerException e1) {
			logger.error(e1.getMessage());
		}
		
	

	}

}
